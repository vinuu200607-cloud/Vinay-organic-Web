let cart = [];

function addToCart(name, price) {
  const item = cart.find(product => product.name === name);
  if (item) {
    item.quantity++;
  } else {
    cart.push({ name, price, quantity: 1 });
  }
  updateCart();
  alert(name + " added to cart!");
}

function updateCart() {
  const count = cart.reduce((total, item) => total + item.quantity, 0);
  document.getElementById("cartCount").innerText = count;
}

function showCart() {
  if (cart.length === 0) {
    alert("Your cart is empty!");
    return;
  }

  let message = "YOUR VINAY'S ORGANIC CART\n\n";
  let total = 0;

  cart.forEach(item => {
    const subtotal = item.price * item.quantity;
    total += subtotal;
    message += `${item.name} x ${item.quantity} = ₹${subtotal}\n`;
  });

  message += `\nTotal Amount: ₹${total}`;
  alert(message);
}
